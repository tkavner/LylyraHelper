local trigger = {}

trigger.name = "LylyraHelper/SS2024/SetFlagStatesOnRespawnTrigger"
trigger.placements = {
    name = "Set Flag States On Respawn Trigger",
    data = {
        flags = ""
    }
}

return trigger
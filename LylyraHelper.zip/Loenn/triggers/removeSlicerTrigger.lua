local removeSlicerTrigger = {}
removeSlicerTrigger.name = "LylyraHelper/RemoveSlicerTrigger"
removeSlicerTrigger.placements = {
	name = "Remove Slicer Trigger",
	data = {
		singleUse = false,
		roomwide = false,
		onLoadOnly=false,
		flag="",
		invert=false
	}}


return removeSlicerTrigger
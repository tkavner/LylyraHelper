local dependencyTrigger = {}
dependencyTrigger.name = "LylyraHelper/DependencyTrigger"
dependencyTrigger.placements = {
	name = "Dependency Trigger",
	data = {
		dependency="",
		flag="",
		invert=false
	}}


return dependencyTrigger
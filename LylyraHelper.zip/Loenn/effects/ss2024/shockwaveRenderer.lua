local shockwaveRenderer = {}

shockwaveRenderer.name = "LylyraHelper/SS2024/ShockwaveRenderer"


shockwaveRenderer.canBackground = true
shockwaveRenderer.canForeground = true

return shockwaveRenderer
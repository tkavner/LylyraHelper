local stringField = require("ui.forms.fields.string")

local listOfTypeField = {}
listOfTypeField.fieldType = "LylyraHelper.TypeField"


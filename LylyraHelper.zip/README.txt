README

Installation

Drop the zip folder in Celeste/Mods/ idk you probably just got it on Gamebanana why are you even reading this I should probably make a more full version of this but this should work for now.




